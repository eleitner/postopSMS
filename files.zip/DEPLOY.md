# Patient Self-Enrollment via SMS

## What This Does
Patients text JOIN to enroll themselves. No clinician needed.

## Patient Flow
1. Text JOIN to (443) 798-3999
2. Name
3. Surgeon last name
4. Procedure (auto-normalizes)
5. Surgery date (TODAY/TOMORROW/date)
6. Recovery goal (or SKIP)
7. Confirm YES
8. Enrolled

## Files (4)
- NEW: src/services/self-enrollment.js
- NEW: migrations/006-enrollment-method.js
- MODIFIED: src/services/session-manager.js
- MODIFIED: src/index.js (trust proxy fix)

## Deploy
1. Copy files to C:\Users\evanl\postop-sms
2. git add -A && git commit -m "feat: patient self-enrollment" && git push origin master
3. Render shell: node migrations/006-enrollment-method.js
4. Test: text JOIN to +14437983999

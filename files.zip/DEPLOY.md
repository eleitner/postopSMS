# Escalation Outcome Follow-Up — Deploy Instructions

## What This Does
When a nurse dispositions with office_visit, office_visit_urgent, or ed_sameday, 
the system now schedules a 48h follow-up asking the patient if they went, what happened, 
and how they're feeling. Re-escalates to nurse if patient didn't go and is still 
symptomatic, or went but feeling worse.

## Files (7 total)

### NEW FILES (2):
- `src/services/escalation-followup.js` — Core logic for outcome tracking
- `migrations/005-escalation-followup.js` — DB migration (adds metadata column + responses table)

### MODIFIED FILES (5):
- `src/services/nurse-templates.js` — Hooks into sendDisposition to schedule follow-ups
- `src/services/session-manager.js` — Routes patient responses to escalation handler
- `src/services/scheduler.js` — Marks escalation follow-ups as awaiting_response after send
- `src/routes/dashboard.js` — Adds escalation outcomes to patient detail API
- `dashboard/index.html` — Renders escalation outcome log in patient detail panel

## Deploy Steps

### 1. Copy files to your local repo
```
cd C:\Users\evanl\postop-sms

# New files
copy deploy-escalation-followup\src\services\escalation-followup.js src\services\escalation-followup.js
copy deploy-escalation-followup\migrations\005-escalation-followup.js migrations\005-escalation-followup.js

# Modified files (overwrites)
copy deploy-escalation-followup\src\services\nurse-templates.js src\services\nurse-templates.js
copy deploy-escalation-followup\src\services\session-manager.js src\services\session-manager.js
copy deploy-escalation-followup\src\services\scheduler.js src\services\scheduler.js
copy deploy-escalation-followup\src\routes\dashboard.js src\routes\dashboard.js
copy deploy-escalation-followup\dashboard\index.html dashboard\index.html
```

### 2. Push to GitHub
```
git add -A
git commit -m "feat: escalation outcome follow-up — 48h post-disposition patient check-in with re-escalation"
git push origin main
```

### 3. Render auto-deploys from GitHub push

### 4. Run migration on Render
Go to Render dashboard → postopsms → Shell tab:
```
node migrations/005-escalation-followup.js
```

This adds:
- `metadata` JSONB column to `scheduled_followups` table
- `escalation_outcome_responses` table with indexes

### 5. Verify
- Dashboard patient detail should now show "Escalation Follow-Up Outcomes" section
- After a nurse dispositions with office_visit/ed_sameday, a follow-up will be scheduled 48h out
- The scheduler picks it up, sends the prompt, patient responds through branching flow
